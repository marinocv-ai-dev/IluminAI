# IluminAI: Rare Disease Intelligence

> *No breakthrough starts from zero.*
> Hack-Nation 7th Global AI Hackathon · Challenge 05: **AI Atlas for the World's Rare Diseases**

IluminAI is a 3D knowledge graph of rare-disease evidence that an AI **walks through out loud**. It lights up each gene, mechanism, community, and study while it explains the connection, and every claim keeps its source.

Our first slice is **CACNA1A**, one gene with several diseases:

| Variant effect | Disease |
|---|---|
| Loss of function | Episodic ataxia type 2 (EA2) |
| Gain of function | Familial hemiplegic migraine type 1 (FHM1) |
| CAG / polyglutamine expansion | Spinocerebellar ataxia type 6 (SCA6) |
| De novo | Developmental and epileptic encephalopathy 42 (DEE42) |

It demonstrates the two ideas the challenge asks for:
1. **Same gene ≠ same disease.** A therapy that silences CACNA1A could help FHM1 (gain of function) and harm EA2 (loss of function). The graph models **variant → mechanism**, not just gene names.
2. **Different genes, same mechanism.** ATP1A2 and SCN1A also cause hemiplegic migraine. KCNA1, CACNB4 and SLC1A3 also cause episodic ataxia. These are communities that could share research without knowing it.

---

## Quick start

```bash
cd atlas
cp .env.example .env.local      # add an LLM key (Groq free tier works)
npm install
npm run dev                     # http://localhost:5173  (Chrome or Edge, for voice)
```
- **▶ Demo**: scripted journey of a family with EA2. No LLM needed.
- **Explore**: ask a question in natural language. The AI answers step by step and illuminates the graph.
- **Click any link**: evidence panel with source, quote, status, confidence and contradictions.

## Reproduce the dataset

```bash
python scripts/fix_ids.py        # resolve every ID against official APIs (writes data/id_map.json, data/gaps.md)
python scripts/verify_ids.py     # independent audit: 0 MISMATCH / 0 NOT FOUND expected
python scripts/build_graph.py    # validate the data contract → atlas/public/data/graph.json
```
Current graph: **107 nodes, 193 links** (90 observed / 100 extracted / 3 inferred). Audit log: `data/gaps.md`.

---

## Architecture

```
┌──────────── DATA PIPELINE (offline, Python) ────────────┐
│ LLM-assisted research → data/nodes.jsonl, edges.jsonl   │
│ fix_ids.py    → every ID resolved via official APIs     │
│ verify_ids.py → audit against HGNC, HPO, NCBI, CT.gov   │
│ build_graph.py→ contract validation → graph.json        │
└─────────────────────────────────────────────────────────┘
                         │ static file
┌──────────── BROWSER (React + Three.js) ─────────────────┐
│ 🎤 Web Speech API → question text                        │
│ subgraph.ts  → Graph-RAG retrieval (≤2.5k tokens)        │
│ POST /api/ask ───────────────┐                           │
│ drop invented ids ◄──────────┤ JSON script of steps      │
│ for each step:               │                           │
│   Graph3D lights + camera    │                           │
│   voice reads the step       │                           │
└──────────────────────────────┼───────────────────────────┘
┌──────────── SERVERLESS (Vercel Functions) ──────────────┐
│ api/ask.ts → LLM (OpenAI gpt-oss-120b on Groq / OpenAI)  │
└─────────────────────────────────────────────────────────┘
```

Key decisions:
- **The graph is a static file, not a database.** It is read-only and small, so it lives in browser memory. No infrastructure to run.
- **The LLM never sees the whole graph.** It only gets a scored, budgeted subgraph. This saves tokens and limits hallucination.
- **The LLM does not drive the UI directly.** It returns a *script*, and the browser validates it and plays it. One LLM call per question, and light and voice stay in sync by design.

---

## Data model

### Nodes
```json
{"id":"HGNC:1388","type":"gene","label":"CACNA1A","synonyms":["Cav2.1"],
 "summary_plain":"Gene for a calcium channel that lets nerve cells send signals.","cluster":"cav21"}
```
12 types: `disease · gene · variant · mechanism · phenotype · patient_group · paper · study · asset · researcher · funder · treatment`.

Stable identifiers, so anyone can verify them:

| Prefix | Source | Example |
|---|---|---|
| `OMIM:` | OMIM | `OMIM:108500` (EA2) |
| `HGNC:` | HUGO Gene Nomenclature | `HGNC:1388` (CACNA1A) |
| `HP:` | Human Phenotype Ontology | `HP:0001251` (Ataxia) |
| `ClinVar:` | ClinVar | `ClinVar:8504` (p.Ser218Leu) |
| `PMID:` | PubMed | `PMID:15136697` |
| `NCT…` | ClinicalTrials.gov | `NCT01543750` |
| `org: person: asset: tx: mech: funder:` | curated slugs | `org:ataxia-uk` |

`synonyms` power the single search box ("EA2", "Cav2.1" and "episodic ataxia" all resolve to the same node). `summary_plain` is written for families, not specialists.

### Links: every edge carries its evidence
```json
{"id":"L12","source":"HGNC:1388","target":"OMIM:108500","type":"causes",
 "status":"observed","confidence":0.95,
 "evidence":[{"source":"OMIM","url":"https://omim.org/entry/108500","quote":"…"}],
 "contradicts":[]}
```

| `status` | Meaning |
|---|---|
| `observed` | From a **curated database** (OMIM, HPO, ClinVar, ClinicalTrials.gov, NIH RePORTER) |
| `extracted` | From a **paper**, with a literal quote from the abstract |
| `inferred` | A **hypothesis** generated by the system (confidence ≤ 0.6) |

- `contradicts` points to links this evidence conflicts with. They are rendered in amber.
- Hard rule: **no link without `evidence[0].url`**. `build_graph.py` rejects it.

---

## Anti-hallucination layers

| # | Where | Prevents |
|---|---|---|
| 1 | `fix_ids.py` | Invented PMIDs, NCTs or variants. Every ID comes from a real HTTP response |
| 2 | `verify_ids.py` | An ID that exists but points to something else |
| 3 | `build_graph.py` | Links without a source, dangling endpoints, invalid status |
| 4 | System prompt | The LLM using knowledge outside the provided subgraph |
| 5 | `App.tsx` | The LLM illuminating node or link ids it was not given |
| 6 | UI + voice | Users confusing a hypothesis with a fact (status is always shown and spoken) |

Why layer 1 exists: the first LLM-generated draft had correct biology but **fabricated identifiers** (0/14 PMIDs, 0/8 ClinVar variants and 0/6 trials pointed to the right record). Any ID that cannot be resolved by an API is now dropped and logged in `data/gaps.md`.

---

## 3D rendering (`atlas/src/Graph3D.tsx`)

- **`react-force-graph-3d`** (Three.js / WebGL + d3-force-3d). There are no hand-placed coordinates: nodes repel, links act as springs, and **clusters emerge from the connections**. The hemiplegic migraine, episodic ataxia and polyQ-SCA groups form on their own.
- **One reactive input:** `highlight = { nodes, links, focus }`. The component knows nothing about AI or voice. Highlighted nodes turn mint and get a brand-book tag, everything else dims, mint particles flow along highlighted links, and the camera flies to `focus`.
- **Visual encoding (IluminAI Brand Book v3):** navy background. Diseases are white, biology is blue, community and evidence are light blue. **Mint is reserved for what the AI illuminates** (the brand's "signal of discovery"). Link opacity encodes observed > extracted > inferred. Amber marks a contradiction.

## Question flow (Graph-RAG)

1. **Voice → text** with the Web Speech API.
2. **Retrieval** (`subgraph.ts`):
   - Seed nodes come from label and synonym matches.
   - Intent detection (e.g. "group" → `patient_group`).
   - A 2-hop BFS scores each link by `(3 − hop)·10 + status_rank·2 + confidence + intent bonus`.
   - Links are added until a **~2.5k-token budget** is full, then serialized compactly (`L12|HGNC:1388>causes>OMIM:108500|observed|0.95`).
3. **Generation** (`api/ask.ts`):
   - Input is validated at the boundary.
   - One `chat/completions` call with `response_format: json_object`.
   - The prompt requires using only the subgraph, stating each link's status, warning about loss- vs gain-of-function, saying "no route" when there is none, and ending with **one concrete next step**.
4. **Playback:** invented ids are dropped. Each step lights the graph, moves the camera and is spoken aloud.

## LLM providers

| Phase | Provider | Model |
|---|---|---|
| Development | Groq | `openai/gpt-oss-120b` (OpenAI open-weight) |
| Demo / live | OpenAI | `gpt-5-mini` |

Switching providers only changes 4 environment variables (`LLM_BASE_URL`, `LLM_MODEL`, `LLM_KEY`, `LLM_EXTRA`). The code stays the same because both use the OpenAI format. Budget per question is about 4.5k tokens, which fits Groq's free tier of 8k tokens per minute. Keys live only in `.env.local` and in Vercel environment variables.

## Deploy
Import the repo in Vercel with **Root Directory = `atlas`** and set the 4 environment variables. `api/ask.ts` deploys as a serverless function. In local development, `vite.config.ts` serves the same file.

## Repository map
```
atlas/                 web app (Vite + React + TypeScript)
  api/ask.ts           question → script of steps (serverless)
  src/Graph3D.tsx      reactive 3D graph + brand identity
  src/subgraph.ts      Graph-RAG retrieval with token budget
  src/App.tsx          layout, question flow, script player
  public/data/graph.json
  public/brand/        logo assets from the brand book
data/                  nodes/edges.jsonl, id_map.json, gaps.md
scripts/               fix_ids, verify_ids, build_graph
```

## Known limits
- **Clustering** is currently implicit (force layout plus curated `cluster`). Next step: phenotype similarity weighted by HPO information content, plus community detection.
- **Scale:** a static file works up to a few thousand nodes. Beyond that, a graph database with server-side retrieval.
- **Coverage:** one gene and its mechanistic neighbors. The pipeline (research → fix_ids → verify → build) is repeatable for any gene.
- **Not medical advice.** IluminAI helps families and researchers frame better questions. Every path ends in professional validation.
