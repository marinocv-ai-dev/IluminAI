"""Merges nodes.jsonl + edges.jsonl into graph.json for react-force-graph-3d.

Usage:  python scripts/build_graph.py [input_dir] [output]
        python scripts/build_graph.py data atlas/public/data/graph.json   (default)

Validates: JSON per line, existing endpoints, evidence URL, valid status and type.
Invalid rows are NOT written: they are reported on the console to be fixed.
"""
import json
import sys
from pathlib import Path

NODE_TYPES = {"disease", "gene", "variant", "mechanism", "phenotype", "patient_group", "paper",
              "study", "asset", "researcher", "funder", "treatment"}
STATUSES = {"observed", "extracted", "inferred"}


def read_jsonl(path):
    rows, bad = [], []
    for n, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = line.strip().rstrip(",")
        if not line or line.startswith(("```", "--")):  # tolerates code fences pasted as-is from an LLM
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError as e:
            bad.append(f"{path.name}:{n} invalid JSON ({e.msg})")
    return rows, bad


def build(src, out):
    raw_nodes, errors = read_jsonl(src / "nodes.jsonl")
    raw_edges, e2 = read_jsonl(src / "edges.jsonl")
    errors += e2

    nodes = {}
    for n in raw_nodes:
        if not n.get("id") or n.get("type") not in NODE_TYPES:
            errors.append(f"node dropped (id/type): {n.get('id')} {n.get('type')}")
            continue
        if n["id"] in nodes:  # duplicate: merge synonyms, first one wins
            nodes[n["id"]]["synonyms"] = sorted(set(nodes[n["id"]].get("synonyms", []) + n.get("synonyms", [])))
            continue
        n.setdefault("synonyms", [])
        n.setdefault("summary_plain", "")
        n.setdefault("cluster", "other")
        nodes[n["id"]] = n

    links, seen = [], set()
    for e in raw_edges:
        s, t, typ = e.get("source"), e.get("target"), e.get("type")
        why = ("missing endpoint" if s not in nodes or t not in nodes else
               "no evidence[0].url" if not (e.get("evidence") or [{}])[0].get("url") else
               "invalid status" if e.get("status") not in STATUSES else
               "duplicate" if (s, t, typ) in seen else None)
        if why:
            errors.append(f"edge dropped ({why}): {s} -{typ}-> {t}")
            continue
        seen.add((s, t, typ))
        conf = float(e.get("confidence", 0.5))
        if e["status"] == "inferred":
            conf = min(conf, 0.6)  # data contract rule
        links.append({**e, "id": f"L{len(links) + 1}", "confidence": round(max(0.0, min(conf, 1.0)), 2),
                      "contradicts": e.get("contradicts", [])})

    # contradicts arrives as "source->target"; translate to link ids
    by_pair = {f"{l['source']}->{l['target']}": l["id"] for l in links}
    for l in links:
        l["contradicts"] = [by_pair.get(c, c) for c in l["contradicts"]]

    deg = {}
    for l in links:
        for k in (l["source"], l["target"]):
            deg[k] = deg.get(k, 0) + 1
    orphans = [i for i in nodes if i not in deg]

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({"nodes": list(nodes.values()), "links": links}, ensure_ascii=False, indent=1),
                   encoding="utf-8")

    print(f"OK {out}: {len(nodes)} nodes, {len(links)} links "
          f"({sum(l['status'] == 'observed' for l in links)} observed / "
          f"{sum(l['status'] == 'extracted' for l in links)} extracted / "
          f"{sum(l['status'] == 'inferred' for l in links)} inferred)")
    if orphans:
        print(f"WARNING {len(orphans)} nodes without links (will float): {', '.join(orphans[:10])}")
    for msg in errors:
        print("ERROR", msg)
    return nodes, links, errors


if __name__ == "__main__":
    src = Path(sys.argv[1] if len(sys.argv) > 1 else "data")
    out = Path(sys.argv[2] if len(sys.argv) > 2 else "atlas/public/data/graph.json")
    build(src, out)
