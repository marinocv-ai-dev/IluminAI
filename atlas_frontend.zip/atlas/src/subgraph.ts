// Cuts the graph down to what is relevant for a question, within a token budget (Graph-RAG retrieval).
// Usage: const { text, nodeIds, linkIds } = buildContext(graph, question)  → `text` goes to the LLM.

type Node = { id: string; type: string; label: string; synonyms?: string[]; summary_plain?: string }
type Link = { id: string; source: any; target: any; type: string; status: string; confidence: number }
type Graph = { nodes: Node[]; links: Link[] }

// ponytail: tokens ≈ chars/4; use a real tokenizer if the budget gets tight
const BUDGET_TOKENS = 2500
const STATUS_RANK: Record<string, number> = { observed: 3, extracted: 2, inferred: 1 }
// word in the question (EN/ES) → node type to prioritize
const INTENT: [RegExp, string][] = [
  [/famil|grupo|group|communit|patient|comunidad/i, 'patient_group'],
  [/trat|treat|drug|medic|terap|therap/i, 'treatment'],
  [/ensayo|trial|estudio|study|registr/i, 'study'],
  [/investig|research|doctor|lab|quien|who/i, 'researcher'],
  [/s[ií]ntoma|symptom|phenotyp/i, 'phenotype'],
  [/modelo|model|asset|biomark/i, 'asset'],
]

const idOf = (x: any) => (typeof x === 'object' ? x.id : x) // force-graph replaces ids with objects
const norm = (s: string) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')

export function buildContext(g: Graph, question: string) {
  const q = norm(question)
  const byId = new Map(g.nodes.map(n => [n.id, n]))
  const adj = new Map<string, Link[]>()
  for (const l of g.links)
    for (const end of [idOf(l.source), idOf(l.target)]) (adj.get(end) ?? adj.set(end, []).get(end)!).push(l)

  // 1. seeds: nodes whose label/synonym appears in the question (min. 3 chars)
  const seeds = g.nodes.filter(n =>
    [n.label, ...(n.synonyms ?? [])].some(s => s.length >= 3 && q.includes(norm(s))))
  const wanted = new Set(INTENT.filter(([re]) => re.test(question)).map(([, t]) => t))

  // 2. 2-hop BFS; links are scored by relevance, then added until the budget is full
  const dist = new Map(seeds.map(n => [n.id, 0]))
  const cand: { l: Link; score: number }[] = []
  let frontier = seeds.map(n => n.id)
  for (let hop = 1; hop <= 2; hop++) {
    const next: string[] = []
    for (const id of frontier)
      for (const l of adj.get(id) ?? []) {
        const other = idOf(l.source) === id ? idOf(l.target) : idOf(l.source)
        const t = byId.get(other)?.type ?? ''
        cand.push({ l, score: (3 - hop) * 10 + STATUS_RANK[l.status] * 2 + l.confidence + (wanted.has(t) ? 8 : 0) })
        if (!dist.has(other)) { dist.set(other, hop); next.push(other) }
      }
    frontier = next
  }
  cand.sort((a, b) => b.score - a.score)

  // 3. compact serialization (no URLs or quotes: the UI shows those from graph.json)
  const nodeLine = (n: Node) => `${n.id}|${n.type}|${n.label}|${(n.summary_plain ?? '').slice(0, 90)}`
  const nodeIds = new Set<string>(), linkIds = new Set<string>(), lines: string[] = []
  let chars = 0
  const add = (s: string) => { lines.push(s); chars += s.length + 1 }
  const addNode = (id: string) => { if (!nodeIds.has(id) && byId.has(id)) { nodeIds.add(id); add('N ' + nodeLine(byId.get(id)!)) } }

  seeds.forEach(n => addNode(n.id))
  for (const { l } of cand) {
    if (chars / 4 > BUDGET_TOKENS) break
    if (linkIds.has(l.id)) continue
    linkIds.add(l.id)
    addNode(idOf(l.source)); addNode(idOf(l.target))
    add(`L ${l.id}|${idOf(l.source)}>${l.type}>${idOf(l.target)}|${l.status}|${l.confidence}`)
  }
  return { text: lines.join('\n'), nodeIds, linkIds, seeds: seeds.map(n => n.id) }
}

// self-check: node --experimental-strip-types ref/subgraph.ts
const argv1: string | undefined = (globalThis as any).process?.argv?.[1] // undefined in the browser
if (argv1 && import.meta.url.endsWith(argv1.replace(/\\/g, '/'))) {
  const g: Graph = {
    nodes: [
      { id: 'G', type: 'gene', label: 'CACNA1A', synonyms: ['Cav2.1'] },
      { id: 'D1', type: 'disease', label: 'Episodic ataxia type 2', synonyms: ['EA2'] },
      { id: 'D2', type: 'disease', label: 'FHM1' },
      { id: 'P', type: 'patient_group', label: 'CACNA1A Foundation' },
      { id: 'X', type: 'gene', label: 'UNRELATED' },
    ],
    links: [
      { id: 'L1', source: 'G', target: 'D1', type: 'causes', status: 'observed', confidence: 0.9 },
      { id: 'L2', source: 'G', target: 'D2', type: 'causes', status: 'observed', confidence: 0.9 },
      { id: 'L3', source: 'P', target: 'D1', type: 'member_of', status: 'extracted', confidence: 0.7 },
    ],
  }
  const r = buildContext(g, '¿Qué grupo de familias hay para EA2?')
  console.assert(r.seeds.join() === 'D1', 'seed by synonym')
  console.assert(r.linkIds.has('L3') && r.nodeIds.has('P'), 'patient group included')
  console.assert(!r.nodeIds.has('X'), 'unrelated node excluded')
  console.assert([...r.linkIds][0] === 'L3', '"group" intent prioritizes patient_group')
  console.log(r.text, '\nOK')
}
