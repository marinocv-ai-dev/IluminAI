import { useEffect, useState } from 'react'
import Graph3D, { BRAND, GROUPS, TAG, type Highlight } from './Graph3D'
import { buildContext } from './subgraph'

type Step = { say: string; nodes: string[]; links: string[]; focus: string }

// Scripted demo on the real graph (same shape /api/ask returns). Lets us test light + camera + voice without an LLM.
// Links are empty on purpose: play() lights every link between the step's nodes, so ids survive graph rebuilds.
const DEMO: Step[] = [
  { say: 'Your child has episodic ataxia type 2. Let us start there.', nodes: ['OMIM:108500'], links: [], focus: 'OMIM:108500' },
  { say: 'It comes from the CACNA1A gene, which builds a calcium channel in nerve cells.', nodes: ['OMIM:108500', 'HGNC:1388'], links: [], focus: 'HGNC:1388' },
  { say: 'The same gene causes other conditions with different names: hemiplegic migraine, spinocerebellar ataxia 6 and an early epilepsy.', nodes: ['HGNC:1388', 'OMIM:108500', 'OMIM:141500', 'OMIM:183086', 'OMIM:617106'], links: [], focus: 'HGNC:1388' },
  { say: 'Careful: in your case the channel lets too little calcium in. In hemiplegic migraine it lets in too much. A therapy for one could harm the other.', nodes: ['OMIM:108500', 'mech:loss-of-function', 'OMIM:141500', 'mech:gain-of-function'], links: [], focus: 'mech:loss-of-function' },
  { say: 'Still, one researcher studies both conditions and built mouse models for them. That is a bridge between two communities.', nodes: ['person:arn-van-den-maagdenberg', 'OMIM:108500', 'OMIM:141500', 'asset:r192q-knockin-mouse', 'asset:s218l-knockin-mouse'], links: [], focus: 'person:arn-van-den-maagdenberg' },
  { say: 'A phase 3 trial is recruiting right now, and it pools three CACNA1A conditions in one study: ataxia type 6, your condition, and hemiplegic migraine.', nodes: ['NCT07221292', 'OMIM:183086', 'OMIM:108500', 'OMIM:141500'], links: [], focus: 'NCT07221292' },
  { say: 'The CACNA1A Foundation also runs a natural history study with Dr. Wendy Chung. That data is what future trials will need.', nodes: ['org:cacna1a-foundation', 'asset:cacna1a-natural-history-study', 'person:wendy-chung'], links: [], focus: 'asset:cacna1a-natural-history-study' },
  { say: 'Next step this week: ask your neurologist whether your child is eligible for the trial, and enroll in the foundation natural history study.', nodes: ['NCT07221292', 'asset:cacna1a-natural-history-study', 'OMIM:108500'], links: [], focus: 'NCT07221292' },
]
const EMPTY: Highlight = { nodes: new Set(), links: new Set() }
const idOf = (x: any) => (typeof x === 'object' ? x.id : x)

export default function App() {
  const [graph, setGraph] = useState<{ nodes: any[]; links: any[] } | null>(null)
  const [hl, setHl] = useState<Highlight>(EMPTY)
  const [said, setSaid] = useState<string[]>([])
  const [evidence, setEvidence] = useState<any>(null)
  const [q, setQ] = useState('')
  const [busy, setBusy] = useState(false)

  useEffect(() => { fetch('/data/graph.json').then(r => r.json()).then(setGraph) }, [])

  // ?step=N shows demo step N without voice (verification and screenshots for the video)
  useEffect(() => {
    const n = Number(new URLSearchParams(location.search).get('step'))
    if (!graph || !n || !DEMO[n - 1]) return
    const s = DEMO[n - 1], nodes = new Set(s.nodes)
    const between = graph.links.filter(l => nodes.has(idOf(l.source)) && nodes.has(idOf(l.target))).map(l => l.id)
    // wait for the layout to settle, like a user clicking Demo after load
    const t = setTimeout(() => { setHl({ nodes, links: new Set(between), focus: s.focus }); setSaid(DEMO.slice(0, n).map(d => d.say)) }, 4500)
    return () => clearTimeout(t)
  }, [graph])

  // ponytail: browser voice; swap for /api/tts (ElevenLabs) without touching the flow
  const speak = (text: string) => new Promise<void>(res => {
    const u = new SpeechSynthesisUtterance(text)
    u.lang = /[áéíóúñ¿¡]/i.test(text) ? 'es-MX' : 'en-US'
    u.onend = u.onerror = () => res()
    speechSynthesis.speak(u)
  })

  // real question: cut subgraph → /api/ask → drop invented ids → play
  const ask = async () => {
    if (!graph || !q.trim()) return
    setBusy(true)
    const { text, nodeIds, linkIds } = buildContext(graph as any, q)
    const r = await fetch('/api/ask', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ question: q, context: text }) })
    const out = await r.json()
    setBusy(false)
    if (!r.ok) return setSaid([`⚠ ${out.error}: ${out.detail ?? ''}`])
    console.log('usage', out.usage)
    const steps: Step[] = out.steps.map((s: Step) => ({
      ...s, nodes: s.nodes.filter(id => nodeIds.has(id)), links: s.links.filter(id => linkIds.has(id)),
      focus: nodeIds.has(s.focus) ? s.focus : s.nodes.find(id => nodeIds.has(id)) ?? '',
    }))
    await play([...steps, { say: out.next_step, nodes: [], links: [], focus: '' }].filter(s => s.say))
  }

  const play = async (script: Step[] = DEMO) => {
    if (!graph) return
    speechSynthesis.cancel()
    setSaid([])
    for (const s of script) {
      const nodes = new Set(s.nodes)
      const between = graph.links.filter(l => nodes.has(idOf(l.source)) && nodes.has(idOf(l.target))).map(l => l.id)
      setHl({ nodes, links: new Set([...s.links, ...between]), focus: s.focus })
      setSaid(p => [...p, s.say])
      await speak(s.say)
    }
  }

  if (!graph) return <p className="sora" style={{ color: BRAND.mist, padding: 24 }}>Loading graph…</p>
  return (
    <div style={{ position: 'fixed', inset: 0 }}>
      <Graph3D data={graph} highlight={hl} onLinkClick={setEvidence} />

      <header className="topbar">
        <img src="/brand/logo-dark.png" alt="IluminAI" />
        <form className="search" onSubmit={e => { e.preventDefault(); ask() }}>
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search disease, gene, or symptom… or ask a question" />
          <button className="btn btn-mint" disabled={busy}>{busy ? 'Searching…' : 'Explore'}</button>
        </form>
        <button className="btn btn-ghost" onClick={() => play()}>▶ Demo</button>
        <button className="btn btn-ghost" onClick={() => { speechSynthesis.cancel(); setHl(EMPTY); setSaid([]) }}>Reset</button>
      </header>

      <aside className="card left">
        <p className="eyebrow">Evidence path</p>
        <h3>{said.length ? 'Following the evidence' : 'Explore the graph and follow the evidence.'}</h3>
        {said.length > 0 && <ol className="steps">{said.map((t, i) => <li key={i}>{t}</li>)}</ol>}
        <div className="legend">
          {GROUPS.map(g => <span key={g.name}><span className="dot" style={{ background: g.color, outline: '1px solid #c5d3e0' }} />{g.name}</span>)}
          <span><span className="dot" style={{ background: BRAND.mint }} />Illuminated by the AI</span>
          <span><span className="dot" style={{ background: '#F2B134' }} />Contradictory evidence</span>
        </div>
      </aside>

      {evidence && (
        <aside className="card right">
          <p className="eyebrow">{TAG[graph.nodes.find(n => n.id === idOf(evidence.source))?.type] ?? ''} · connection</p>
          <h3>{evidence.type.replace(/_/g, ' ')}</h3>
          <p style={{ fontSize: 14 }}><b>{evidence.status}</b> · confidence {Math.round(evidence.confidence * 100)}%</p>
          {evidence.evidence?.map((e: any, i: number) => (
            <p key={i} style={{ fontSize: 14 }}><a href={e.url} target="_blank" rel="noreferrer">{e.source}</a> — “{e.quote}”</p>
          ))}
          {evidence.contradicts?.length > 0 && <p className="warn">⚠ Contradicts: {evidence.contradicts.join(', ')}</p>}
          <button className="btn btn-mint" onClick={() => setEvidence(null)}>Close</button>
        </aside>
      )}
    </div>
  )
}
