// 3D graph the AI can illuminate · IluminAI identity (Brand Book v3)
// Usage: <Graph3D data={graph} highlight={{ nodes, links, focus }} onLinkClick={showEvidence} />
import { useEffect, useMemo, useRef } from 'react'
import ForceGraph3D from 'react-force-graph-3d'
import SpriteText from 'three-spritetext'

export type Highlight = { nodes: Set<string>; links: Set<string>; focus?: string }

// Official palette. Mint is reserved for "signals of discovery" = what the AI illuminates.
export const BRAND = { navy: '#0A2E4E', blue: '#1E6091', mint: '#4CC9B0', mist: '#F4F7FA' }

// As on the brand book cover: white and blue nodes on navy; the exact type goes in the tag (GEN, HPO…).
// ponytail: blue is lightened (#3D85C6) because #1E6091 on navy lacks contrast in 3D
export const GROUPS = [
  { name: 'Diseases', color: BRAND.mist, types: ['disease'] },
  { name: 'Biology', color: '#3D85C6', types: ['gene', 'variant', 'mechanism', 'phenotype'] },
  { name: 'Community & evidence', color: '#8FB3D1', types: ['patient_group', 'researcher', 'funder', 'study', 'asset', 'treatment', 'paper'] },
]
const GROUP_COLOR = Object.fromEntries(GROUPS.flatMap(g => g.types.map(t => [t, g.color])))
export const TAG: Record<string, string> = {
  disease: 'DX', gene: 'GEN', variant: 'VAR', mechanism: 'MECH', phenotype: 'HPO', patient_group: 'GROUP',
  researcher: 'RES', funder: 'FUND', study: 'STUDY', asset: 'ASSET', treatment: 'TX', paper: 'EVID',
}
const DIM = 'rgba(30,96,145,0.28)' // dimmed brand blue
const CONTRADICTION = '#F2B134'     // only off-palette color: a semantic alert, not decoration
const idOf = (x: any) => (typeof x === 'object' ? x.id : x)

export default function Graph3D({ data, highlight, onNodeClick, onLinkClick }: {
  data: { nodes: any[]; links: any[] }
  highlight: Highlight
  onNodeClick?: (n: any) => void
  onLinkClick?: (l: any) => void
}) {
  const fg = useRef<any>(null)
  const fitted = useRef(false)
  const active = highlight.nodes.size > 0
  const graphData = useMemo(() => data, [data]) // same reference = simulation does not restart

  const degree = useMemo(() => {
    const d: Record<string, number> = {}
    data.links.forEach(l => [idOf(l.source), idOf(l.target)].forEach(k => (d[k] = (d[k] ?? 0) + 1)))
    return d
  }, [data])

  // spread the layout so clusters separate (defaults pack ~100 nodes into a tight ball)
  useEffect(() => {
    fg.current?.d3Force('charge').strength(-140)
    fg.current?.d3Force('link').distance((l: any) => (l.type === 'has_phenotype' ? 30 : 55))
  }, [])

  // camera flight to the focus node (official 3d-force-graph pattern)
  const flyTo = (id?: string) => {
    const n = data.nodes.find(n => n.id === id)
    if (!n || n.x === undefined || !fg.current) return false
    const ratio = 1 + 280 / Math.hypot(n.x, n.y, n.z || 1)
    fg.current.cameraPosition({ x: n.x * ratio, y: n.y * ratio, z: n.z * ratio }, n, 1400)
    return true
  }
  useEffect(() => { flyTo(highlight.focus) }, [highlight.focus, data])

  const linkColor = (l: any) => {
    const lit = highlight.links.has(l.id)
    if (l.contradicts?.length && (lit || !active)) return CONTRADICTION
    if (lit) return BRAND.mint
    if (active) return 'rgba(143,179,209,0.06)'
    return l.status === 'inferred' ? 'rgba(143,179,209,0.25)' : `rgba(143,179,209,${l.status === 'observed' ? 0.6 : 0.42})`
  }

  return (
    <ForceGraph3D
      ref={fg}
      graphData={graphData}
      backgroundColor={BRAND.navy}
      nodeVal={n => (n.id === highlight.focus ? 10 : 2) + (degree[n.id] ?? 0)}
      nodeColor={n => (highlight.nodes.has(n.id) ? BRAND.mint : active ? DIM : GROUP_COLOR[n.type] ?? '#8FB3D1')}
      nodeOpacity={1}
      nodeResolution={24}
      nodeLabel={n => `<div class="tip"><span class="tag">${TAG[n.type] ?? n.type}</span> <b>${n.label}</b><br/>${n.summary_plain ?? ''}</div>`}
      // brand book tag (navy box + mint text) only on illuminated nodes
      nodeThreeObjectExtend
      nodeThreeObject={(n: any) => {
        if (!highlight.nodes.has(n.id)) return undefined as any
        const s = new SpriteText(`${TAG[n.type] ?? ''}  ${n.label}`)
        s.fontFace = 'Manrope, sans-serif'
        s.fontWeight = '600'
        s.color = n.id === highlight.focus ? BRAND.navy : BRAND.mint
        s.backgroundColor = n.id === highlight.focus ? BRAND.mint : 'rgba(10,46,78,0.92)'
        s.padding = [3, 2]
        s.borderRadius = 2
        s.textHeight = n.id === highlight.focus ? 7 : 5
        s.position.y = 4 * Math.cbrt((n.id === highlight.focus ? 10 : 2) + (degree[n.id] ?? 0)) + 6 // above the sphere (nodeRelSize 4)
        return s
      }}
      cooldownTime={4000}
      // layout settles after first render: fly to a pending focus, otherwise fit the whole graph once
      onEngineStop={() => { if (fitted.current) return; fitted.current = true; if (!flyTo(highlight.focus)) fg.current?.zoomToFit(800, 60) }}
      linkColor={linkColor}
      linkWidth={l => (highlight.links.has(l.id) ? 1 + 1.5 * l.confidence : 0)} // 0 = native hairline (as in the brand book)
      linkDirectionalParticles={l => (highlight.links.has(l.id) ? 3 : 0)}
      linkDirectionalParticleColor={() => BRAND.mint}
      linkDirectionalParticleWidth={2}
      linkDirectionalParticleSpeed={0.007}
      linkLabel={l => `<div class="tip">${l.type} · ${l.status} · ${Math.round(l.confidence * 100)}%</div>`}
      onNodeClick={onNodeClick}
      onLinkClick={onLinkClick}
    />
  )
}
