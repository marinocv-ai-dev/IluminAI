// POST /api/ask  { question, context }  →  guion { status, steps[], next_step, gaps[] }
// Provider set by env (OpenAI format): Groq in development, OpenAI for the demo. See .env.example
// `context` = output of buildContext() (src/subgraph.ts), already cut to ~2.5k tokens.

const SYSTEM = `You are the guide of the Rare Disease Atlas, talking to a family with no medical background.
You receive a QUESTION and a SUBGRAPH. Lines: "N id|type|label|summary" are nodes, "L id|source>relation>target|status|confidence" are links.
Use ONLY the subgraph. Never invent ids, facts, names or numbers.
Return ONLY a JSON object:
{"status":"supported|partial|no_route",
 "steps":[{"say":"1-2 short sentences","nodes":["node ids mentioned"],"links":["link ids used"],"focus":"one node id"}],
 "next_step":"one concrete action","gaps":["what is missing"]}
Rules:
- 3 to 6 steps. Walk the route hop by hop; each step only uses ids that appear in the subgraph.
- Say whether each link is observed (curated database), from a paper (extracted) or inferred (hypothesis).
- Same gene does not mean same disease: if variants act in opposite ways (loss vs gain of function), warn clearly.
- If a link has contradictions, say so.
- If the subgraph does not support an answer, status "no_route": explain what was searched and what evidence is missing.
- next_step: ONE concrete action this week (who to contact, what asset to reuse, what to validate).
- Plain words, short sentences, calm tone. Answer in the same language as the QUESTION.`

const STATUSES = ['supported', 'partial', 'no_route']
const strs = (x: unknown) => (Array.isArray(x) ? x.filter(s => typeof s === 'string') : [])

export type Step = { say: string; nodes: string[]; links: string[]; focus: string }
export type Script = { status: string; steps: Step[]; next_step: string; gaps: string[] }

// Normalizes LLM output; throws if unusable. Filtering ids against the graph happens in the browser.
export function parseScript(raw: string): Script {
  const j = JSON.parse(raw.slice(raw.indexOf('{'), raw.lastIndexOf('}') + 1))
  const steps: Step[] = (Array.isArray(j.steps) ? j.steps : [])
    .filter((s: any) => typeof s?.say === 'string' && s.say.trim())
    .slice(0, 8)
    .map((s: any) => {
      const nodes = strs(s.nodes)
      return { say: s.say.trim(), nodes, links: strs(s.links), focus: typeof s.focus === 'string' ? s.focus : nodes[0] ?? '' }
    })
  if (!steps.length) throw new Error('script has no steps')
  return {
    status: STATUSES.includes(j.status) ? j.status : 'partial',
    steps,
    next_step: typeof j.next_step === 'string' ? j.next_step : '',
    gaps: strs(j.gaps),
  }
}

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } })

export async function POST(req: Request): Promise<Response> {
  const env = (globalThis as any).process.env
  const { question, context } = await req.json().catch(() => ({}))
  // limits at the trust boundary: protect the token budget and the key
  if (typeof question !== 'string' || !question.trim() || question.length > 500)
    return json({ error: 'question required (max 500 chars)' }, 400)
  if (typeof context !== 'string' || context.length > 12000)
    return json({ error: 'context required (max 12000 chars)' }, 400)
  if (!env.LLM_KEY) return json({ error: 'LLM_KEY missing in .env.local' }, 500)

  const r = await fetch(`${env.LLM_BASE_URL}/chat/completions`, {
    method: 'POST',
    headers: { authorization: `Bearer ${env.LLM_KEY}`, 'content-type': 'application/json' },
    body: JSON.stringify({
      model: env.LLM_MODEL,
      messages: [
        { role: 'system', content: SYSTEM },
        { role: 'user', content: `QUESTION: ${question}\n\nSUBGRAPH:\n${context || '(empty: no matching nodes)'}` },
      ],
      response_format: { type: 'json_object' },
      max_completion_tokens: 1500,
      ...JSON.parse(env.LLM_EXTRA || '{}'), // provider-specific params (e.g. reasoning_effort)
    }),
  })
  if (!r.ok) return json({ error: `LLM ${r.status}`, detail: (await r.text()).slice(0, 500) }, r.status === 429 ? 429 : 502)

  const data = await r.json()
  try {
    return json({ ...parseScript(data.choices?.[0]?.message?.content ?? ''), usage: data.usage })
  } catch (e) {
    return json({ error: 'invalid LLM response', detail: String(e) }, 502)
  }
}

// self-check: node --experimental-strip-types api/ask.ts
const argv1: string | undefined = (globalThis as any).process?.argv?.[1]
if (argv1 && import.meta.url.endsWith(argv1.replace(/\\/g, '/'))) {
  const s = parseScript('leading text {"status":"raro","steps":[{"say":" Hola ","nodes":["A",3]},{"say":""}],"gaps":"x"}')
  console.assert(s.status === 'partial', 'unknown status → partial')
  console.assert(s.steps.length === 1 && s.steps[0].say === 'Hola', 'empty steps dropped')
  console.assert(s.steps[0].focus === 'A' && s.steps[0].nodes.join() === 'A', 'default focus + non-string ids dropped')
  console.assert(Array.isArray(s.gaps) && s.gaps.length === 0, 'non-array gaps → []')
  let threw = false
  try { parseScript('{"steps":[]}') } catch { threw = true }
  console.assert(threw, 'no steps → error')
  console.log('OK')
}
